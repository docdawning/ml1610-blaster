Here's just a dump of files I got together in order to get my modern macOS machines to print through my very very old Samsung ML-1610 laser printer. This printer's a little gem that with some software support, still works quite well.

I've blogged about this thing a few times, such as <a href="https://dawning.ca/2017/samsung-ml-1610-on-macos-high-sierra/">here</a>.

<BR />
-<a target="_new" href="https://jamessnell.com">James T Snell</a>
